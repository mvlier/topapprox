# topsimp
 Package for computing topological simplification of functions on 2-manifolds (possibly with boundary) using Persistent Homology.
